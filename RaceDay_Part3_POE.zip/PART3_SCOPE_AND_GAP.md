# Part 3 integration notes

The code supplied here is the MVC client portion. It intentionally does not recreate database logic or access SQL Server directly.

Before final submission, compare `Services/RaceDayApi.cs` and `Models/ApiModels.cs` with the real Part 2 API:
1. Confirm the exact login/register route and JSON property names.
2. Confirm whether login returns a bearer token and user role.
3. Confirm event, category, enrolment and result route names.
4. Confirm the exact DTO fields and whether event categories are included in event details.
5. Confirm how result publication is represented by the API.
6. Add API-side role authorization and validate all incoming data.

The uploaded SQL script defines UserAccount, OrganiserProfile, ParticipantProfile, Event, Category, Enrollment and Result. The MVC project uses those concepts but relies on the REST API to read/write them.
