using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;

namespace RaceDay.Mvc.Controllers;

public class OrganiserController : Controller
{
    private readonly IRaceDayApi _api;
    private readonly IBlobStorageService _blob;

    public OrganiserController(IRaceDayApi api, IBlobStorageService blob)
    {
        _api = api;
        _blob = blob;
    }

    private bool IsOrganiser() => HttpContext.Session.GetString("Role") == "Organiser";

    public async Task<IActionResult> Dashboard()
    {
        if (!IsOrganiser()) return Forbid();
        return View(await _api.GetEventsAsync());
    }

    public async Task<IActionResult> Events()
    {
        if (!IsOrganiser()) return Forbid();
        return View(await _api.GetEventsAsync());
    }

    [HttpGet]
    public IActionResult CreateEvent()
    {
        if (!IsOrganiser()) return Forbid();
        return View(new EventDto { EventDate = DateTime.Today });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateEvent(EventDto model, IFormFile? banner)
    {
        if (!IsOrganiser()) return Forbid();

        if (banner is not null && banner.Length > 0)
        {
            try { model.BannerUrl = await _blob.UploadAsync(banner); }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Banner upload failed: " + ex.Message);
                return View(model);
            }
        }

        if (!await _api.SaveEventAsync(model))
        {
            ModelState.AddModelError("", "Could not save event through the API.");
            return View(model);
        }

        TempData["Message"] = "Event saved.";
        return RedirectToAction(nameof(Events));
    }

    [HttpGet]
    public async Task<IActionResult> EditEvent(int id)
    {
        if (!IsOrganiser()) return Forbid();
        var item = await _api.GetEventAsync(id);
        return item is null ? NotFound() : View(item);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> EditEvent(EventDto model, IFormFile? banner)
    {
        if (!IsOrganiser()) return Forbid();

        if (banner is not null && banner.Length > 0)
        {
            try { model.BannerUrl = await _blob.UploadAsync(banner); }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Banner upload failed: " + ex.Message);
                return View(model);
            }
        }

        if (!await _api.SaveEventAsync(model))
        {
            ModelState.AddModelError("", "Could not update event.");
            return View(model);
        }

        return RedirectToAction(nameof(Events));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        if (!IsOrganiser()) return Forbid();
        await _api.DeleteEventAsync(id);
        return RedirectToAction(nameof(Events));
    }

    public async Task<IActionResult> Enrollments(int id)
    {
        if (!IsOrganiser()) return Forbid();
        ViewBag.EventId = id;
        return View(await _api.GetEventEnrollmentsAsync(id));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> UpdateEnrollment(int enrollmentId, string status, int eventId)
    {
        if (!IsOrganiser()) return Forbid();
        await _api.UpdateEnrollmentStatusAsync(enrollmentId, status);
        return RedirectToAction(nameof(Enrollments), new { id = eventId });
    }

    [HttpGet]
    public IActionResult AddCategory(int eventId)
    {
        if (!IsOrganiser()) return Forbid();
        return View(new CategoryDto { EventId = eventId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AddCategory(CategoryDto model)
    {
        if (!IsOrganiser()) return Forbid();
        if (!await _api.SaveCategoryAsync(model.EventId, model))
        {
            ModelState.AddModelError("", "Could not save category.");
            return View(model);
        }
        return RedirectToAction(nameof(Events));
    }

    public async Task<IActionResult> Results(int id)
    {
        if (!IsOrganiser()) return Forbid();
        ViewBag.EventId = id;
        return View(await _api.GetEventEnrollmentsAsync(id));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveResult(ResultDto model, int eventId)
    {
        if (!IsOrganiser()) return Forbid();
        await _api.SaveResultAsync(model);
        return RedirectToAction(nameof(Results), new { id = eventId });
    }
}
