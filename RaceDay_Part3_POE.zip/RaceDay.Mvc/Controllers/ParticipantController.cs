using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Services;

namespace RaceDay.Mvc.Controllers;

public class ParticipantController : Controller
{
    private readonly IRaceDayApi _api;

    public ParticipantController(IRaceDayApi api) => _api = api;

    private bool IsParticipant() => HttpContext.Session.GetString("Role") == "Participant";

    public async Task<IActionResult> Index(string? search, string? type)
    {
        if (!IsParticipant()) return Forbid();
        ViewBag.Search = search;
        ViewBag.Type = type;
        return View(await _api.GetEventsAsync(search, type));
    }

    public async Task<IActionResult> Details(int id)
    {
        if (!IsParticipant()) return Forbid();
        var item = await _api.GetEventAsync(id);
        return item is null ? NotFound() : View(item);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Enroll(int eventId, int categoryId)
    {
        if (!IsParticipant()) return Forbid();
        var success = await _api.EnrollAsync(eventId, categoryId);
        TempData["Message"] = success ? "You have enrolled successfully." : "Enrolment could not be completed.";
        return RedirectToAction(nameof(Details), new { id = eventId });
    }

    public async Task<IActionResult> MyEnrollments()
    {
        if (!IsParticipant()) return Forbid();
        return View(await _api.GetMyEnrollmentsAsync());
    }

    public async Task<IActionResult> MyResults()
    {
        if (!IsParticipant()) return Forbid();
        return View(await _api.GetMyResultsAsync());
    }
}
