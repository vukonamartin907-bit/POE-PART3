namespace RaceDay.Mvc.Models;

public class LoginRequest
{
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
}

public class RegisterRequest
{
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
    public string Role { get; set; } = "Participant";
}

public class AuthResponse
{
    public int UserId { get; set; }
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Role { get; set; } = "";
    public string Token { get; set; } = "";
}

public class EventDto
{
    public int EventId { get; set; }
    public string EventName { get; set; } = "";
    public string Description { get; set; } = "";
    public string EventType { get; set; } = "Run";
    public DateTime EventDate { get; set; }
    public string Venue { get; set; } = "";
    public string City { get; set; } = "";
    public string Status { get; set; } = "Planned";
    public string? BannerUrl { get; set; }
    public List<CategoryDto> Categories { get; set; } = new();
}

public class CategoryDto
{
    public int CategoryId { get; set; }
    public int EventId { get; set; }
    public string CategoryName { get; set; } = "";
    public decimal DistanceKm { get; set; }
    public int MaxParticipants { get; set; }
    public decimal EntryFee { get; set; }
}

public class EnrollmentDto
{
    public int EnrollmentId { get; set; }
    public int EventId { get; set; }
    public int CategoryId { get; set; }
    public int ParticipantId { get; set; }
    public int RaceNumber { get; set; }
    public string Status { get; set; } = "";
    public string EventName { get; set; } = "";
    public string CategoryName { get; set; } = "";
}

public class ResultDto
{
    public int ResultId { get; set; }
    public int EnrollmentId { get; set; }
    public string? FinishTime { get; set; }
    public int? Position { get; set; }
    public string ResultStatus { get; set; } = "Pending";
}

public class ProfileDto
{
    public int UserId { get; set; }
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Role { get; set; } = "";
}
