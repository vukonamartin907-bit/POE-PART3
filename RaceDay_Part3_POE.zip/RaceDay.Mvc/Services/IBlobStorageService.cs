namespace RaceDay.Mvc.Services;

public interface IBlobStorageService
{
    Task<string> UploadAsync(IFormFile file);
}
