using RaceDay.Mvc.Models;

namespace RaceDay.Mvc.Services;

public interface IRaceDayApi
{
    Task<AuthResponse?> LoginAsync(LoginRequest request);
    Task<bool> RegisterAsync(RegisterRequest request);
    Task<List<EventDto>> GetEventsAsync(string? search = null, string? type = null);
    Task<EventDto?> GetEventAsync(int id);
    Task<bool> SaveEventAsync(EventDto item);
    Task<bool> DeleteEventAsync(int id);
    Task<bool> SaveCategoryAsync(int eventId, CategoryDto item);
    Task<List<EnrollmentDto>> GetEventEnrollmentsAsync(int eventId);
    Task<List<EnrollmentDto>> GetMyEnrollmentsAsync();
    Task<bool> EnrollAsync(int eventId, int categoryId);
    Task<bool> UpdateEnrollmentStatusAsync(int enrollmentId, string status);
    Task<bool> SaveResultAsync(ResultDto result);
    Task<List<ResultDto>> GetMyResultsAsync();
}
