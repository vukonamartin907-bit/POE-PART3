using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace RaceDay.Mvc.Services;

public class BlobStorageService : IBlobStorageService
{
    private readonly IConfiguration _configuration;

    public BlobStorageService(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public async Task<string> UploadAsync(IFormFile file)
    {
        var connection = _configuration["AzureBlobStorage:ConnectionString"];
        var containerName = _configuration["AzureBlobStorage:ContainerName"];

        if (string.IsNullOrWhiteSpace(connection))
            throw new InvalidOperationException("Azure Blob Storage connection string is not configured.");

        var container = new BlobContainerClient(connection, containerName);
        await container.CreateIfNotExistsAsync(PublicAccessType.None);

        var extension = Path.GetExtension(file.FileName);
        var blobName = $"{Guid.NewGuid()}{extension}";
        var blob = container.GetBlobClient(blobName);

        await using var stream = file.OpenReadStream();
        await blob.UploadAsync(stream, new BlobHttpHeaders
        {
            ContentType = file.ContentType
        });

        return blob.Uri.ToString();
    }
}
