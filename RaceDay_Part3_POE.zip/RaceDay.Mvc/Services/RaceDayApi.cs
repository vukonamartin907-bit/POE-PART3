using System.Net.Http.Headers;
using System.Net.Http.Json;
using RaceDay.Mvc.Models;

namespace RaceDay.Mvc.Services;

public class RaceDayApi : IRaceDayApi
{
    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _accessor;

    public RaceDayApi(HttpClient http, IHttpContextAccessor accessor)
    {
        _http = http;
        _accessor = accessor;
    }

    private void AddToken()
    {
        var token = _accessor.HttpContext?.Session.GetString("ApiToken");
        _http.DefaultRequestHeaders.Authorization = string.IsNullOrWhiteSpace(token)
            ? null : new AuthenticationHeaderValue("Bearer", token);
    }

    public async Task<AuthResponse?> LoginAsync(LoginRequest request)
    {
        var response = await _http.PostAsJsonAsync("api/auth/login", request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<AuthResponse>();
    }

    public async Task<bool> RegisterAsync(RegisterRequest request)
    {
        var response = await _http.PostAsJsonAsync("api/auth/register", request);
        return response.IsSuccessStatusCode;
    }

    public async Task<List<EventDto>> GetEventsAsync(string? search = null, string? type = null)
    {
        AddToken();
        var url = "api/events";
        var query = new List<string>();
        if (!string.IsNullOrWhiteSpace(search)) query.Add("search=" + Uri.EscapeDataString(search));
        if (!string.IsNullOrWhiteSpace(type)) query.Add("type=" + Uri.EscapeDataString(type));
        if (query.Count > 0) url += "?" + string.Join("&", query);
        return await _http.GetFromJsonAsync<List<EventDto>>(url) ?? new();
    }

    public async Task<EventDto?> GetEventAsync(int id)
    {
        AddToken();
        return await _http.GetFromJsonAsync<EventDto>($"api/events/{id}");
    }

    public async Task<bool> SaveEventAsync(EventDto item)
    {
        AddToken();
        var response = item.EventId == 0
            ? await _http.PostAsJsonAsync("api/events", item)
            : await _http.PutAsJsonAsync($"api/events/{item.EventId}", item);
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> DeleteEventAsync(int id)
    {
        AddToken();
        return (await _http.DeleteAsync($"api/events/{id}")).IsSuccessStatusCode;
    }

    public async Task<bool> SaveCategoryAsync(int eventId, CategoryDto item)
    {
        AddToken();
        var response = item.CategoryId == 0
            ? await _http.PostAsJsonAsync($"api/events/{eventId}/categories", item)
            : await _http.PutAsJsonAsync($"api/events/{eventId}/categories/{item.CategoryId}", item);
        return response.IsSuccessStatusCode;
    }

    public async Task<List<EnrollmentDto>> GetEventEnrollmentsAsync(int eventId)
    {
        AddToken();
        return await _http.GetFromJsonAsync<List<EnrollmentDto>>(
            $"api/events/{eventId}/enrolments") ?? new();
    }

    public async Task<List<EnrollmentDto>> GetMyEnrollmentsAsync()
    {
        AddToken();
        return await _http.GetFromJsonAsync<List<EnrollmentDto>>("api/enrolments/me") ?? new();
    }

    public async Task<bool> EnrollAsync(int eventId, int categoryId)
    {
        AddToken();
        var response = await _http.PostAsJsonAsync(
            $"api/events/{eventId}/enrolments", new { CategoryId = categoryId });
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> UpdateEnrollmentStatusAsync(int enrollmentId, string status)
    {
        AddToken();
        var response = await _http.PutAsJsonAsync(
            $"api/enrolments/{enrollmentId}/status", new { Status = status });
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> SaveResultAsync(ResultDto result)
    {
        AddToken();
        var response = result.ResultId == 0
            ? await _http.PostAsJsonAsync("api/results", result)
            : await _http.PutAsJsonAsync($"api/results/{result.ResultId}", result);
        return response.IsSuccessStatusCode;
    }

    public async Task<List<ResultDto>> GetMyResultsAsync()
    {
        AddToken();
        return await _http.GetFromJsonAsync<List<ResultDto>>("api/results/me") ?? new();
    }
}
