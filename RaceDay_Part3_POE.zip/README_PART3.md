# RaceDay – Part 3 POE (ASP.NET Core MVC)

## What is included
- ASP.NET Core MVC front end using C# and Bootstrap.
- Calls the Part 2 REST API through `HttpClient`; this MVC project does not connect directly to SQL Server.
- Session-based login and role-specific Organiser and Participant pages.
- Organiser event management, banner upload, categories, enrolment status management and result entry.
- Participant event browsing/filtering, event details, enrolment, personal enrolments and results.
- Azure Blob Storage service for event banner images.
- Dockerfile for containerising the MVC application.

## Important source limitation
The uploaded Part 2 ZIP contains only `POE Part2_RaceDay.sql` (the SQL Server database script). It does not contain the Part 2 ASP.NET Core Web API source code or its exact request/response DTOs. The uploaded Part 1 PDF contains a GitHub Actions validation workflow, not the full Part 1 assignment brief. Therefore, this MVC project uses the endpoint paths listed by the Part 1 validation workflow and conventional JSON DTO shapes. It must be matched to the actual Part 2 API before it can be considered fully integrated or demonstrated as working end-to-end.

## Requirements
- .NET 8 SDK
- Running Part 2 RaceDay REST API
- Azure Storage account/container for event banners (optional until banner upload is used)

## Configure the API
Edit `RaceDay.Mvc/appsettings.json` and set `ApiSettings:BaseUrl` to the actual Part 2 API URL, for example `https://localhost:7001/`.

Expected API routes used by this MVC project:
- `POST api/auth/register`
- `POST api/auth/login`
- `GET api/profile`
- `GET/POST api/events`
- `GET/PUT/DELETE api/events/{id}`
- `POST api/events/{id}/categories`
- `GET api/events/{id}/enrolments`
- `POST api/events/{id}/enrolments`
- `GET api/enrolments/me`
- `PUT api/enrolments/{id}/status`
- `POST/PUT api/results`
- `GET api/results/me`

Some routes beyond the minimum Part 1 validation list are assumptions for the Part 3 features and may need to be adjusted to match Part 2.

## Configure Azure Blob Storage
Set the connection string securely using a user secret or environment variable. Do not commit real credentials.
Example environment variable:
`AzureBlobStorage__ConnectionString=<your-connection-string>`
Set `AzureBlobStorage__ContainerName=event-banners`.

## Run locally
From the `RaceDay.Mvc` directory:
```bash
dotnet restore
dotnet build
dotnet run
```
Open the local URL printed by the .NET CLI.

## Docker
From the `RaceDay.Mvc` directory:
```bash
docker build -t raceday-mvc .
docker run --rm -p 8080:8080   -e ApiSettings__BaseUrl=https://host.docker.internal:7001/   -e AzureBlobStorage__ConnectionString="<your-connection-string>"   raceday-mvc
```

## Security notes
- Session stores the user ID, role and API token.
- The API must still validate the bearer token and enforce roles server-side. Hiding MVC links is not sufficient security.
- For production, configure HTTPS, secure cookies, proper CSRF protection, validation, and secrets outside source control.
